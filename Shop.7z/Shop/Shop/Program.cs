﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shop
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.CursorVisible = false;
            Market cur = new Market();
            int pos = 0;
            cur.ShowBrands(pos);
            while(true)
            {
                ConsoleKeyInfo btn = Console.ReadKey();
                Console.Clear();
                if (btn.Key == ConsoleKey.UpArrow)
                {
                    pos--;
                    if(pos == -1)
                    {
                        pos = 2;
                    }
                }
                if(btn.Key == ConsoleKey.DownArrow)
                {
                    pos++;
                    if (pos == 3)
                        pos = 0;
                }
                if(btn.Key == ConsoleKey.Enter)
                {
                    Console.Clear();
                    cur.showProduct(pos);
                    Console.ReadKey();
                    Console.Clear();
                }
                cur.ShowBrands(pos);
            }
        }
    }
}
